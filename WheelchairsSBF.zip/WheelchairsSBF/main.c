/*
 * Authors: Malek Karray, Anthony Berbari
*/

#include "microphone.h"

/**********************************************************
 * Variables
 *********************************************************/

static bool m_micFlag = false;

/**********************************************************
 * Code
 *********************************************************/

int main(void){

    initMic();

    feedMicFlag(&m_micFlag);

    while(1){

        if (m_micFlag == true)
        {
            volatile int por = 69; // :p
            m_micFlag = false;
        }


    }


    return 0;
}


