/*
 * Authors: Malek Karray, Anthony Berbari
*/
#include <msp430.h>
#include <Board.h>
#include "driverlib.h"
#include "interrupts.h"
#include <stdint.h>
#include "rpm.h"
#include "microphone.h"
#include "ultrasonic.h"
#include "keypad.h"
#include "motorControl.h"
#include "hal_LCD.h"
#include <stdio.h>



/**********************************************************
 * Variables
 *********************************************************/
char string[2];

 typedef struct {

   bool isEmergency;
   bool isOriented;
   float distance;
   rpmValues_t* rpmValues;

}sensorData;

enum modes {KEYPAD, MOTOR};
static sensorData data;


/**********************************************************
 * Prototypes
 *********************************************************/

static void initPeriph();
static void readSensorData(sensorData* res);
static void displayData(sensorData data);
static bool isOriented();
/**********************************************************
 * Code
 *********************************************************/

int main(void){

    initMic();
    initRPM();
    initUltrasonic();
    initPeriph();
    initKeypad();
    initMotorControl();
    Init_LCD();

    enum modes state = KEYPAD;
    bool inputReady = false;



    while (1){
        switch(state){

            case KEYPAD:

                displayScrollText("INPUT COORDINATES");

                inputReady = false;

                while (inputReady == false){

                    debounceHoldAvoidance();
                    inputReady  = keypadInputComplete(string);
                    getDistance();
                }
                showChar('D',pos1);
                showChar('I',pos2);
                showChar('R',pos3);


                if(string[0] == '2')
                {
                    showChar('N',pos5);

                }

                else if(string[0] == '4')
                {
                    showChar('W',pos5);

                }

                else if(string[0] == '6')
                {
                    showChar('E',pos5);

                }

                else if(string[0] == '8')
                {
                    showChar('S',pos5);

                }


                state = MOTOR;
                break;

            case MOTOR:
                readSensorData(&data);
                 if(data.isEmergency){
                     killAll();
                     state = KEYPAD;
                     break;
                 }
                 if(data.isOriented){
                     //orientDirection('L');
                     driveForward();

                 }
                 displayData(data);
                 break;
        }
    }
}

static void readSensorData(sensorData* res){


    volatile float distance =  getDistance();
    if ( (distance < 0.3f) && (distance != 0.0f)){
        res->isEmergency = true;
        volatile int CCS_IS_TRASH = 5;
        return;
    }
    if (emergencyStopRequested()){
        res->isEmergency = true;
        volatile int CCS_IS_TRASH2 = 5;
        return;
    }

    res -> isEmergency = false;
    res -> distance = getDistance();
    res -> rpmValues = getRPM();
    res -> isOriented = isOriented();
    return;
}
static void displayData(sensorData res){
    return;
}
static bool isOriented(){
    return true;
}
static void initPeriph(){

    PMM_unlockLPM5();           // allow writing to registers
    WDTCTL = WDTPW | WDTHOLD;   // Stop watchdog timer
    _EINT();                    // Start interrupt

}

#ifdef 0
    rpmValues_t *rpmValues;
    while(1){
       while(!keypadInputComplete(&string));
        /*emergency stop state*/
        if (emergencyStopRequested()){
            volatile int por = 69; // :p
        }

        /*rpm state*/
        rpmValues = getRPM();
        volatile float test1 = rpmValues->rightWheel;
        volatile float test2 = rpmValues->leftWheel;

        /*ultrasonic*/
        volatile float distance = getDistance();

        /*keypad*/
        char character;
        volatile bool status = getCharacter(&character);
        volatile bool nonsense = userResetRequested();
        volatile float garbanzo = 5;

    }


    return 0;
}
#endif


