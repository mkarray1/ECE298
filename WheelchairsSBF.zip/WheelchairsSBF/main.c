/*
 * Authors: Malek Karray, Anthony Berbari
*/

#include "microphone.h"

/**********************************************************
 * Variables
 *********************************************************/


/**********************************************************
 * Code
 *********************************************************/

int main(void){

    initMic();
    initRPM();
    unsigned int currentRPM;
    while(1){
        /*emergency stop state*/
        if (emergencyStopRequested()){
            volatile int por = 69; // :p
        }

        /*rpm state*/
        //getRPM(&currentRPM);



    }


    return 0;
}


