/*
 * Authors: Malek Karray, Anthony Berbari
*/

#include "interrupts.h"
#include <stdint.h>
#include "rpm.h"
#include "microphone.h"
#include "ultrasonic.h"


/**********************************************************
 * Variables
 *********************************************************/


/**********************************************************
 * Code
 *********************************************************/

int main(void){
#if 0
    setUltrasonicFuncPtr(getUltrasonicTimestamp);
    setRpmFuncPtr(getRpmTimestamp);
    initRPM();
#endif



    initMic();
    initRPM();
    initUltrasonic();

    rpmValues_t *rpmValues;
    while(1){
        /*emergency stop state*/
        if (emergencyStopRequested()){
            volatile int por = 69; // :p
        }

        /*rpm state*/
        rpmValues = getRPM();
        volatile float test1 = rpmValues->rightWheel;
        volatile float test2 = rpmValues->leftWheel;

        /*ultrasonic*/
        volatile float distance = getDistance();
        volatile int shit = 7;
    }


    return 0;
}

