/*
 * Authors: Malek Karray, Anthony Berbari
*/

#include "interrupts.h"
#include <stdint.h>
#include "rpm.h"
#include "microphone.h"


/**********************************************************
 * Variables
 *********************************************************/

static void getUltrasonicTimestamp(uint16_t timestamp);
static void getRpmTimestamp(uint16_t timestamp);

/**********************************************************
 * Code
 *********************************************************/

int main(void){
#if 0
    setUltrasonicFuncPtr(getUltrasonicTimestamp);
    setRpmFuncPtr(getRpmTimestamp);
    initRPM();
#endif



    initMic();
    initRPM();
    initUltrasonic();

    rpmValues_t *rpmValues;
    while(1){
        /*emergency stop state*/
        if (emergencyStopRequested()){
            volatile int por = 69; // :p
        }

        /*rpm state*/
        rpmValues = getRPM();
        volatile float test1 = rpmValues->rightWheel;
        volatile float test2 = rpmValues->leftWheel;

        /*ultrasonic*/
        float distance = getDistance();

    }


    return 0;
}


static void getUltrasonicTimestamp(uint16_t timestamp){

    volatile int garbage = 5;
}

static void getRpmTimestamp(uint16_t timestamp){

    volatile int garbage = 5;
}

