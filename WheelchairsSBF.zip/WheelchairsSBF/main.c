/*
 * Authors: Malek Karray, Anthony Berbari
*/
#include <msp430.h>
#include <Board.h>
#include "driverlib.h"
#include "interrupts.h"
#include <stdint.h>
#include "rpm.h"
#include "microphone.h"
#include "ultrasonic.h"
#include "keypad.h"


/**********************************************************
 * Prototypes
 *********************************************************/

static void initPeriph();

/**********************************************************
 * Code
 *********************************************************/

int main(void){

    //initMic();
    initRPM();
    initUltrasonic();
    initPeriph();
    initKeypad();

    rpmValues_t *rpmValues;
    while(1){
        /*emergency stop state*/
        if (emergencyStopRequested()){
            volatile int por = 69; // :p
        }

        /*rpm state*/
        rpmValues = getRPM();
        volatile float test1 = rpmValues->rightWheel;
        volatile float test2 = rpmValues->leftWheel;

        /*ultrasonic*/
        volatile float distance = getDistance();

        /*keypad*/
        char character = 'a';
        volatile bool status = getCharacter(&character);
        volatile bool nonsense = userResetRequested();
        volatile float garbanzo = 5;

    }


    return 0;
}

static void initPeriph(){

    PMM_unlockLPM5();           // allow writing to registers
    WDTCTL = WDTPW | WDTHOLD;   // Stop watchdog timer
    _EINT();                    // Start interrupt

}
