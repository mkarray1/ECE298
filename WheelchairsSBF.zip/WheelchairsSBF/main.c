/*
 * Authors: Malek Karray, Anthony Berbari
*/
#define _SVID_SOURCE
#include <msp430.h>
#include <Board.h>
#include "driverlib.h"
#include "interrupts.h"
#include <stdint.h>
#include "rpm.h"
#include "microphone.h"
#include "ultrasonic.h"
#include "keypad.h"
#include "motorControl.h"
#include "hal_LCD.h"
#include <stdio.h>
#include <math.h>




/**********************************************************
 * Variables
 *********************************************************/
char string[2];

 typedef struct {

   bool isEmergency;
   bool isOriented;
   float distance;
   rpmValues_t* rpmValues;

}sensorData;

enum modes {KEYPAD, MOTOR};
static sensorData data;


/**********************************************************
 * Prototypes
 *********************************************************/

static void initPeriph();
static void readSensorData(sensorData* res);
static void displayData(sensorData* data);
static bool isOriented();
void ftoa(float n, char *res, int afterpoint);
int intToStr(int x, char str[], int d);
void reverse(char *str, int len);
/**********************************************************
 * Code
 *********************************************************/

int main(void){

    initMic();
    initRPM();
    initUltrasonic();
    initPeriph();
    initKeypad();
    initMotorControl();
    Init_LCD();

    enum modes state = KEYPAD;
    bool inputReady = false;



    while (1){
        switch(state){

            case KEYPAD:

                //displayScrollText("INPUT COORDINATES");

                inputReady = false;

                while (inputReady == false){

                    debounceHoldAvoidance();
                    inputReady  = keypadInputComplete(string);
                    getDistance();
                }
                showChar('D',pos1);
                showChar('I',pos2);
                showChar('R',pos3);


                if(string[0] == '2')
                {
                    showChar('N',pos5);

                }

                else if(string[0] == '4')
                {
                    showChar('W',pos5);

                }

                else if(string[0] == '6')
                {
                    showChar('E',pos5);

                }

                else if(string[0] == '8')
                {
                    showChar('S',pos5);

                }


                state = MOTOR;
                break;

            case MOTOR:
                readSensorData(&data);
                 if(data.isEmergency){
                     killAll();
                     state = KEYPAD;
                     break;
                 }
                 if(data.isOriented){
                     //orientDirection('L');
                     driveForward();

                 }
                 displayData(&data);
                 break;
        }
    }
}

static void readSensorData(sensorData* res){


    volatile float distance =  getDistance();

    if ( (distance < 0.3f) && (distance != 0.0f)){
        res->isEmergency = true;
        volatile int CCS_IS_TRASH = 5;
        return;
    }

    if (emergencyStopRequested()){
        res->isEmergency = true;
        volatile int CCS_IS_TRASH2 = 5;
        return;
    }

    res -> isEmergency = false;
    res -> distance = getDistance();
    res -> rpmValues = getRPM();
    res -> isOriented = isOriented();
    return;
}
static void displayData(sensorData* data){
    static int displayCounter;
    volatile float trash = data->rpmValues->rightWheel;
    volatile int trash2 = (int)fmod(trash, 100.0);



    char charVals[10];

    if (displayCounter >= 1000){
        snprintf(charVals, sizeof(charVals), "%d", trash2);
        clearLCD();
        showChar(charVals[0],pos1);
        showChar(charVals[1],pos2);

        displayCounter = 0;
    }
    displayCounter++;
    return;
}
static bool isOriented(){
    return true;
}
static void initPeriph(){

    PMM_unlockLPM5();           // allow writing to registers
    WDTCTL = WDTPW | WDTHOLD;   // Stop watchdog timer
    _EINT();                    // Start interrupt

}
void reverse(char *str, int len)
{
    int i=0, j=len-1, temp;
    while (i<j)
    {
        temp = str[i];
        str[i] = str[j];
        str[j] = temp;
        i++; j--;
    }
}
int intToStr(int x, char str[], int d)
{
    int i = 0;
    while (x)
    {
        str[i++] = (x%10) + '0';
        x = x/10;
    }

    // If number of digits required is more, then
    // add 0s at the beginning
    while (i < d)
        str[i++] = '0';

    reverse(str, i);
    str[i] = '\0';
    return i;
}
void ftoa(float n, char *res, int afterpoint)
{
    // Extract integer part
    int ipart = (int)n;

    // Extract floating part
    float fpart = n - (float)ipart;

    // convert integer part to string
    int i = intToStr(ipart, res, 0);

    // check for display option after point
    if (afterpoint != 0)
    {
        res[i] = '.';  // add dot

        // Get the value of fraction part upto given no.
        // of points after dot. The third parameter is needed
        // to handle cases like 233.007
        fpart = fpart * pow(10, afterpoint);

        intToStr((int)fpart, res + i + 1, afterpoint);
    }
}
#ifdef 0
    rpmValues_t *rpmValues;
    while(1){
       while(!keypadInputComplete(&string));
        /*emergency stop state*/
        if (emergencyStopRequested()){
            volatile int por = 69; // :p
        }

        /*rpm state*/
        rpmValues = getRPM();
        volatile float test1 = rpmValues->rightWheel;
        volatile float test2 = rpmValues->leftWheel;

        /*ultrasonic*/
        volatile float distance = getDistance();

        /*keypad*/
        char character;
        volatile bool status = getCharacter(&character);
        volatile bool nonsense = userResetRequested();
        volatile float garbanzo = 5;

    }


    return 0;
}
#endif


