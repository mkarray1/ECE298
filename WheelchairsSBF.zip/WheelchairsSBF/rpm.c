/* Authors: Malek Karray, Anthony Berbari
*/


#include <msp430.h>
#include "driverlib.h"
#include "Board.h"
#include "rpm.h"
#include <math.h>

/**********************************************************
 * Defintions
 *********************************************************/

#define MAX_16_BIT_VALUE 0xFFFF
#define TIMEFACTOR 3.05E-4

#define LEFT 2
#define RIGHT 1

/**********************************************************
 * Variables
 *********************************************************/

static rpmValues_t currentVal;

/**********************************************************
 * Prototypes
 *********************************************************/

static void initRpmTimer(void);
static void convertCounter(uint16_t timeStamp, int caller);

/**********************************************************
 * Code
 *********************************************************/

rpmValues_t *getRPM(void){
    return &currentVal;
}


void initRPM(void){

    currentVal.leftWheel = 0;
    currentVal.rightWheel = 0;

    WDT_A_hold(WDT_A_BASE);     // Stop watchdog timer

    initRpmTimer();


    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P2, GPIO_PIN5, GPIO_PRIMARY_MODULE_FUNCTION);     // Column 1: Input direction
    GPIO_selectInterruptEdge(GPIO_PORT_P2, GPIO_PIN5, GPIO_HIGH_TO_LOW_TRANSITION);
    GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P2, GPIO_PIN5);
    GPIO_clearInterrupt(GPIO_PORT_P2, GPIO_PIN5);
    GPIO_enableInterrupt(GPIO_PORT_P2, GPIO_PIN5);


    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P1, GPIO_PIN4, GPIO_PRIMARY_MODULE_FUNCTION);     // Column 2: Input direction
    GPIO_selectInterruptEdge(GPIO_PORT_P1, GPIO_PIN4, GPIO_HIGH_TO_LOW_TRANSITION);
    GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P1, GPIO_PIN4);
    GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN4);
    GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN4);

    _EINT();        // Start interrupt

    PMM_unlockLPM5();           // Need this for LED to turn on- in case of "abnormal off state"
 //   __bis_SR_register(LPM4_bits + GIE);     // Need this for interrupts or else "abnormal termination"

}



static void initRpmTimer(void){

    Timer_A_initContinuousModeParam rpmTimer = {0};
    rpmTimer.clockSource = TIMER_A_CLOCKSOURCE_ACLK;
    rpmTimer.clockSourceDivider = TIMER_A_CLOCKSOURCE_DIVIDER_10;
    rpmTimer.timerInterruptEnable_TAIE = TIMER_A_TAIE_INTERRUPT_DISABLE;
    rpmTimer.timerClear = TIMER_A_DO_CLEAR;
    rpmTimer.startTimer = true;
    Timer_A_initContinuousMode(TIMER_A1_BASE, &rpmTimer);
}

static void convertCounter(uint16_t timeStamp, int caller){
    static int previousTimeStampLeft;
    static int previousTimeStampRight;

    if (caller == LEFT){
        int32_t counter = timeStamp - previousTimeStampLeft;
        previousTimeStampLeft = timeStamp;
        float secondsBetweenRevolutions = fabs( (timeStamp - previousTimeStampLeft) * TIMEFACTOR);
        currentVal.leftWheel = 60 / secondsBetweenRevolutions;
    }

    if (caller == RIGHT){
        int32_t counter = timeStamp - previousTimeStampRight;
        previousTimeStampRight = timeStamp;
        float secondsBetweenRevolutions = fabs( (timeStamp - previousTimeStampRight) * TIMEFACTOR);
        currentVal.rightWheel = 60 / secondsBetweenRevolutions;

    }



}


// SMCLK runs at about in about 1.1MHz


#pragma vector = PORT2_VECTOR       // Using PORT1_VECTOR interrupt because P1.4 and P1.5 are in port 1
__interrupt void PORT2_ISR(void)
{
    /*Left wheel*/
    convertCounter( Timer_A_getCounterValue(TIMER_A1_BASE), LEFT ); //(change to rpm for left wheel)
    GPIO_clearInterrupt(GPIO_PORT_P2, GPIO_PIN5);
}
#pragma vector = PORT1_VECTOR       // Using PORT1_VECTOR interrupt because P1.4 and P1.5 are in port 1
__interrupt void PORT1_ISR(void)
{
    convertCounter( Timer_A_getCounterValue(TIMER_A1_BASE), RIGHT );
    GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN4);
}
