/* DESCRIPTION
 * Sample code structure when with ADC analog input and driving an LED with PWM
 * This example: Turns a LED on at two different brightness level depending on ADC value
*/


#include <msp430.h>
#include "driverlib.h"
#include "Board.h"
#include "microphone.h"


/**********************************************************
 * Variables
 *********************************************************/


 static struct rpmValues {
    unsigned int leftWheel;
    unsigned int rightWheel;
};

struct rpmValues currentVal;
currentVal.leftWheel = 0;
currentVal.rightWheel = 0;

/**********************************************************
 * Code
 *********************************************************/

struct rpmValues getRPM(){
    return currentVal;
}
void initRPM(void){
    WDT_A_hold(WDT_A_BASE);     // Stop watchdog timer



    // COLUMNS ARE ISR TRIGGERS

    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P2, GPIO_PIN5, GPIO_PRIMARY_MODULE_FUNCTION);     // Column 1: Input direction
    GPIO_selectInterruptEdge(GPIO_PORT_P2, GPIO_PIN5, GPIO_HIGH_TO_LOW_TRANSITION);
    GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P2, GPIO_PIN5);
    GPIO_clearInterrupt(GPIO_PORT_P2, GPIO_PIN5);
    GPIO_enableInterrupt(GPIO_PORT_P2, GPIO_PIN5);

    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P1, GPIO_PIN4, GPIO_PRIMARY_MODULE_FUNCTION);     // Column 2: Input direction
    GPIO_selectInterruptEdge(GPIO_PORT_P1, GPIO_PIN4, GPIO_HIGH_TO_LOW_TRANSITION);
    GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P1, GPIO_PIN4);
    GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN4);
    GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN4);

    _EINT();        // Start interrupt

    PMM_unlockLPM5();           // Need this for LED to turn on- in case of "abnormal off state"
    __bis_SR_register(LPM4_bits + GIE);     // Need this for interrupts or else "abnormal termination"
    __no_operation();           //For debugger

}

#pragma vector = PORT2_VECTOR       // Using PORT1_VECTOR interrupt because P1.4 and P1.5 are in port 1
__interrupt void PORT2_ISR(void)
{
    /*Left wheel*/
    currentVal.leftWheel  = 10; //(change to rpm for left wheel)
    GPIO_clearInterrupt(GPIO_PORT_P2, GPIO_PIN5);
}
#pragma vector = PORT1_VECTOR       // Using PORT1_VECTOR interrupt because P1.4 and P1.5 are in port 1
__interrupt void PORT1_ISR(void)
{
    /*Right wheel*/
    currentVal.rightWheel = 10; //(change to rpm for right wheel)
    GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN4);
}
