#include "keypad.h"
#include <msp430.h>
#include "driverlib.h"
#include "Board.h"
#include <stdbool.h>


/**********************************************************
 * Code
 *********************************************************/


void initKeypad(void)
{
    // Row Outputs (to mux, these are actually shared with the led's)
    P1DIR |= ( 1 << 0 );
    P1DIR |= ( 1 << 3 );
    P8DIR |= ( 1 << 1 );

    // Column inputs
    GPIO_setAsInputPinWithPullDownResistor(GPIO_PORT_P8, GPIO_PIN0);
    GPIO_setAsInputPinWithPullDownResistor(GPIO_PORT_P8, GPIO_PIN2);
    GPIO_setAsInputPinWithPullDownResistor(GPIO_PORT_P8, GPIO_PIN3);

}

bool getCharacter(char *character)
{

    // itterate through all combos, save results

    // check row 3
    P1OUT |= ( 1 << 0 );
    P1OUT |= ( 1 << 3 );
    P8OUT |= ( 1 << 1 );

    // column 3
    if (GPIO_getInputPinValue(GPIO_PORT_P8, GPIO_PIN3) == GPIO_INPUT_PIN_HIGH)
    {
        *character = '9';
        volatile int shit =7;
    }

    else if (GPIO_getInputPinValue(GPIO_PORT_P8, GPIO_PIN2) == GPIO_INPUT_PIN_HIGH)
    {
        *character = '8';
        volatile int shit =7;

    }

    else if (GPIO_getInputPinValue(GPIO_PORT_P8, GPIO_PIN0) == GPIO_INPUT_PIN_HIGH)
    {
        *character = '7';
        volatile int shit =7;

    }


    return true;
}

bool userResetRequested(void)
{
    return true;
}
