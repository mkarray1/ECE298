

#include <msp430.h>
#include "driverlib.h"
#include "Board.h"
#include <math.h>





void initMotorControl(void)
{

    P1DIR |= ((1 << 6) | (1 << 7));

    Timer_A_initCompareModeParam PWMA = {0};
    PWMA.compareRegister = TIMER_A_CAPTURECOMPARE_REGISTER_0;
    PWMA.compareInterruptEnable = TIMER_A_CAPTURECOMPARE_INTERRUPT_ENABLE;
    PWMA.compareOutputMode = TIMER_A_OUTPUTMODE_SET;
    PWMA.compareValue = 0xFF;
    Timer_A_initCompareMode(TIMER_A1_BASE, &PWMA);

}


