/*
 * Authors: Anthony Berbari, Malek Karray
*/

#include <stdbool.h>

/**********************************************************
 * Prototypes
 *********************************************************/

void initMic(void);


void feedMicFlag(bool *micFlag);
