/*
 * Authors: Anthony Berbari, Malek Karray
*/

#include <stdbool.h>

/**********************************************************
 * Prototypes
 *********************************************************/

void initRPM(void);

