
#include <msp430.h>
#include "driverlib.h"
#include "Board.h"
#include <stdbool.h>


/**********************************************************
 * variables
 *********************************************************/

static void (*UltrasonicFuncPtr)(uint16_t timestamp);
static void (*RpmFuncPtr)(uint16_t timestamp);
static bool echoCompareFlag = false;

/**********************************************************
 * Prototypes
 *********************************************************/
static bool echoVal(){

    volatile int garbage = GPIO_getInputPinValue(GPIO_PORT_P1, GPIO_PIN5);

    if (garbage == GPIO_INPUT_PIN_LOW){
        return false;
    }

    return true;
}



void setUltrasonicFuncPtr( void (*getUltrasonicTimestamp)(uint16_t timestamp) )
{
    UltrasonicFuncPtr = getUltrasonicTimestamp;
}

void setRpmFuncPtr( void (*getRpmTimestamp)(uint16_t timestamp) )
{
    RpmFuncPtr = getRpmTimestamp;
}

#include <msp430.h>
#include "driverlib.h"
#include "Board.h"
#pragma vector = PORT1_VECTOR
__interrupt void PORT1_ISR(void)
{

    volatile bool echoReading = echoVal();

    /*  Hall effect */
    if (echoCompareFlag == false && echoReading == false){

        RpmFuncPtr(Timer_A_getCounterValue(TIMER_A1_BASE));
        volatile int garb = 10;


    }
    /* Ultrasonic rising edge */
    else if (echoCompareFlag == false && echoReading == true){
        UltrasonicFuncPtr(Timer_A_getCounterValue(TIMER_A0_BASE));
        echoCompareFlag = true;
        GPIO_selectInterruptEdge(GPIO_PORT_P1, GPIO_PIN5, GPIO_HIGH_TO_LOW_TRANSITION);
    }
    /* Ultrasonic falling edge */
    else if (echoCompareFlag == true && echoReading == false){
        UltrasonicFuncPtr(Timer_A_getCounterValue(TIMER_A0_BASE));
        echoCompareFlag = false;
        GPIO_selectInterruptEdge(GPIO_PORT_P1, GPIO_PIN5, GPIO_LOW_TO_HIGH_TRANSITION);
    }
    /* hall effect */
    else{
        RpmFuncPtr(Timer_A_getCounterValue(TIMER_A1_BASE));
        volatile int garb = 10;
    }

    //convertCounter( Timer_A_getCounterValue(TIMER_A1_BASE), RIGHT );
    GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN4);
    GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN5);

}
