#include <msp430.h>
#include "driverlib.h"
#include "Board.h"
#include <math.h>
#include "interrupts.h"

#define TIMEFACTOR 9.9E-7
#define SPEED_OF_SOUND 340
/**********************************************************
 * Variables
 *********************************************************/

static float m_newestDistance;

/**********************************************************
 * Prototypes
 *********************************************************/

static void sendNewTrigger(void);
static void getUltrasonicTimestamp(uint16_t timestamp);

/**********************************************************
 * Code
 *********************************************************/
static void getUltrasonicTimestamp(uint16_t timestamp){
    static uint16_t previousTimestamp;
    static bool isFallingEdge;
    int32_t counter = timestamp - previousTimestamp;
    previousTimestamp = timestamp;
    if (isFallingEdge == true){
        volatile float secondsBetweenRevolutions = fabs( counter * TIMEFACTOR);
        float distance = (secondsBetweenRevolutions * SPEED_OF_SOUND) / 2;
        m_newestDistance = distance;
    }
    isFallingEdge ^= 1;
}





static void initUltrasonicTimer(void){

    Timer_A_initContinuousModeParam ultrasonicTimer= {0};
    ultrasonicTimer.clockSource = TIMER_A_CLOCKSOURCE_SMCLK;
    ultrasonicTimer.clockSourceDivider = TIMER_A_CLOCKSOURCE_DIVIDER_1;
    ultrasonicTimer.timerInterruptEnable_TAIE = TIMER_A_TAIE_INTERRUPT_DISABLE;
    ultrasonicTimer.timerClear = TIMER_A_DO_CLEAR;
    ultrasonicTimer.startTimer = true;
    Timer_A_initContinuousMode(TIMER_A0_BASE, &ultrasonicTimer);
}
void initUltrasonic(void){
    initUltrasonicTimer();
    setUltrasonicFuncPtr(getUltrasonicTimestamp);

    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P1, GPIO_PIN5, GPIO_PRIMARY_MODULE_FUNCTION);     // Column 2: Input direction
    GPIO_selectInterruptEdge(GPIO_PORT_P1, GPIO_PIN5, GPIO_LOW_TO_HIGH_TRANSITION);
    GPIO_setAsInputPin(GPIO_PORT_P1, GPIO_PIN5);
    GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN5);
    GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN5);

    WDTCTL = WDTPW | WDTHOLD;               // Stop watchdog timer
    PM5CTL0 &= ~LOCKLPM5;                   // Disable the GPIO power-on default high-impedance mode
                                            // to activate previously configured port settings
                         // Set P1.0 to output direction

    P1DIR |= (1<<3);
    P1OUT &= ~(1<<3);

    sendNewTrigger();

}

float getDistance(void){

    sendNewTrigger();

    return m_newestDistance;
}


static void sendNewTrigger(void){

    P1OUT ^= ( 1<<3 );
    __delay_cycles(5);
    P1OUT ^= ( 1<<3 );
}














