/*
 * Authors: Anthony Berbari, Malek Karray
*/

#include <stdbool.h>

/**********************************************************
 * Prototypes
 *********************************************************/

void initMic(void);


bool emergencyStopRequested(void);
