#include <msp430.h>
#include "driverlib.h"
#include "Board.h"
#include <math.h>
#include "interrupts.h"
/**********************************************************
 * Variables
 *********************************************************/

static float m_newestDistance;

/**********************************************************
 * Prototypes
 *********************************************************/

static void sendNewTrigger(void);
static void getUltrasonicTimestamp(uint16_t timestamp);

/**********************************************************
 * Code
 *********************************************************/
void getUltrasonicTimestamp(uint16_t timestamp){


}
void initUltrasonic(void){
    setUltrasonicFuncPtr(getUltrasonicTimestamp);

    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P1, GPIO_PIN5, GPIO_PRIMARY_MODULE_FUNCTION);     // Column 2: Input direction
    GPIO_selectInterruptEdge(GPIO_PORT_P1, GPIO_PIN5, GPIO_LOW_TO_HIGH_TRANSITION);
    GPIO_setAsInputPin(GPIO_PORT_P1, GPIO_PIN5);
    GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN5);
    GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN5);

    WDTCTL = WDTPW | WDTHOLD;               // Stop watchdog timer
    PM5CTL0 &= ~LOCKLPM5;                   // Disable the GPIO power-on default high-impedance mode
                                            // to activate previously configured port settings
                         // Set P1.0 to output direction

    P1DIR |= 0x10;
    P1OUT &= ~(0x10);


/*
    for (;;){
        P1OUT ^= 0x10;
        __delay_cycles(4);
        P1OUT ^= 0x10;
        __delay_cycles(400000);
    }
*/
    /*for(;;) {
        volatile unsigned int i;            // volatile to prevent optimization

        P1OUT ^= 0x10;

    }*/
}

float getDistance(void){

    sendNewTrigger();

    return m_newestDistance;
}


static void sendNewTrigger(void){

    P5OUT |= 0x1;
    __delay_cycles(4);
    P5OUT &= ~(0x1);
}














